package consensus

type RequestMsg struct {
	Timestamp  int64  `json:"timestamp"`
	ClientID   string `json:"clientID"`
	Operation  string `json:"operation"`
	SequenceID int64  `json:"sequenceID"`
	RingOrder  []int  `json:"ringorder"`
}

type ReplyMsg struct {
	ViewID    int64  `json:"viewID"`
	Timestamp int64  `json:"timestamp"`
	ClientID  string `json:"clientID"`
	NodeID    string `json:"nodeID"`
	Result    string `json:"result"`
}

type PrePrepareMsg struct {
	ViewID     int64       `json:"viewID"`
	SequenceID int64       `json:"sequenceID"`
	Digest     string      `json:"digest"`
	RequestMsg *RequestMsg `json:"requestMsg"`
}

type VoteMsg struct {
	ViewID     int64  `json:"viewID"`
	SequenceID int64  `json:"sequenceID"`
	Digest     string `json:"digest"`
	NodeID     string `json:"nodeID"`
	MsgType    `json:"msgType"`
}

// The paper uses asymmetric crpytography to achieve DS
// For simplicity, utilize symmetric crpytography here
// TODO: DS implementation
type GlobalForwardMsg struct {
	ReqMsg *RequestMsg `json:"reqMsg"`
	// DigitalSignature string   `json:"digitalsignature`
	CommitMsg *VoteMsg `json:commitMsg`
	Digest    string   `json:"digest"`
}

type LocalForwardMsg struct {
	GlobalForwardMsg *GlobalForwardMsg `json:"globalForwardMsg"`
}

type MsgType int

const (
	PrepareMsg MsgType = iota
	CommitMsg
)
