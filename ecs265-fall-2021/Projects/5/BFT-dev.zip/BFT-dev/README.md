# Implement RingBFT in Go

## Introduction
### Origin
Course Project of ECS 265

Paper of RingBFT paper can be found here: https://arxiv.org/abs/2107.13047

### PBFT Program base
From https://github.com/bigpicturelabs/simple_pbft

It's an implementation of PBFT in Go without the client

### Implemented
- Global share
- Local share
- Message verification
- Automated testing script
- Hard code ring order

### Unimplemented
- Unstable execution
- Digital Signature
- Execution Inform Message

## Usage

Please refer to the test.sh

## Result

### Shard 1

![](shard1.png)

### Shard 2

![](shard2.png)