#!/bin/bash

# Premise: At least needs 3 terminals
# Instructions: 
# ./test.sh help -> Helper function
# ./test.sh kill -> Kill all tmux server
# ./test.sh [1-9]+ -> Create a new shard and make 4 running replicas attach to it
# ./test.sh send -> Send curl request to the first shard

set -Eeuo pipefail

# TODO: install tmux and recognize OS
if [[ "$#" != 1 || "${1}" = "help" ]]; then
	echo "Usage: ./test.sh {kill|send|[0-9]+}" && exit 1
fi

OS=$(uname -s)
if [ ${OS} = "Darwin" ]; then
	type tmux &> /dev/null
	if [ "$?" -ne 0 ]; then
		brew install tmux
	fi
fi

set -x

if [ "${1}" = "kill" ]; then
	tmux kill-server
elif [ "${1}" = "send" ]; then
	curl -H "Content-Type: application/json" -X POST -d '{"clientID":"ahnhwi","operation":"GetMyName","timestamp":859381532, "RingOrder":[1, 2]}' http://localhost:1111/req
elif [[ "${1}" =~ ^[0-9]+$ ]]; then
	if $(tmux has-session -t shard${1}); then
		tmux kill-session -t shard${1}
	fi
	tmux new-session -d -s "shard${1}" -n "r${1}_1" 
	tmux new-window -d -n "r${1}_2" -t "shard${1}"
	tmux new-window -d -n "r${1}_3" -t "shard${1}" 
	tmux new-window -d -n "p${1}_0" -t "shard${1}"
	tmux send -t "r${1}_1" "go run . r${1}_1" ENTER
	tmux send -t "r${1}_2" "go run . r${1}_2" ENTER
	tmux send -t "r${1}_3" "go run . r${1}_3" ENTER
	tmux send -t "p${1}_0" "go run . p${1}_0" ENTER
	tmux attach-session -t "shard${1}"
else
	echo "Input Error: Only send, kill and [0-9]+ will be accepted" && exit 1
fi